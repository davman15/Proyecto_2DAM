package com.example.animezone.Clase

class Usuario(
    val nombreUsuario: String? = null,
    val apellidos:String?=null,
    val correo: String? = null,
    val usuarioId: String? = null,
    val contrasena: String? = null,
    val imagen:String?=null
)